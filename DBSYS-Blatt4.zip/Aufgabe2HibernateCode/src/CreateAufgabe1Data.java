
/**
 * Licensee: Laboradmin(HTWG Konstanz)
 * License Type: Academic
 */
import org.orm.*;

public class CreateAufgabe1Data {
	public void createTestData() throws PersistentException {
		PersistentTransaction t = Aufgabe1PersistentManager.instance().getSession().beginTransaction();
		try {
			Studiengang studiengang = StudiengangDAO.createStudiengang();
			studiengang.setKuerzel("ain");
			studiengang.setAbschluss("Bachelor");
			studiengang.setName("Angewandte Informatik");
			Studiengang win = StudiengangDAO.createStudiengang();
			win.setKuerzel("win");
			win.setAbschluss("Bachelor");
			win.setName("Wirtschafts Informatik");
			// TODO Initialize the properties of the persistent object here, the following
			// properties must be initialized before saving : vorlesung
			StudiengangDAO.save(studiengang);
			StudiengangDAO.save(win);

			Vorlesung vorlesung = VorlesungDAO.createVorlesung();
			vorlesung.setName("DBSYS2");
			vorlesung.setEcts(5);
			vorlesung.setSws(5);
			vorlesung.setStudiengang(studiengang);
			VorlesungDAO.save(vorlesung);
			Vorlesung vorlesung2 = VorlesungDAO.createVorlesung();
			vorlesung2.setName("Verteile Systeme");
			vorlesung2.setEcts(5);
			vorlesung2.setSws(5);
			vorlesung2.setStudiengang(win);
			VorlesungDAO.save(vorlesung2);
			Vorlesung vorlesung3 = VorlesungDAO.createVorlesung();
			vorlesung3.setName("Web-Applikationen");
			vorlesung3.setEcts(5);
			vorlesung3.setSws(5);
			vorlesung3.setStudiengang(win);
			VorlesungDAO.save(vorlesung3);
			Vorlesung vorlesung4 = VorlesungDAO.createVorlesung();
			vorlesung4.setName("Betriebssysteme");
			vorlesung4.setEcts(5);
			vorlesung4.setSws(5);
			vorlesung4.setStudiengang(studiengang);
			VorlesungDAO.save(vorlesung4);
			Vorlesung vorlesung5 = VorlesungDAO.createVorlesung();
			vorlesung5.setName("Rechnernetze");
			vorlesung5.setEcts(5);
			vorlesung5.setSws(5);
			vorlesung5.setStudiengang(studiengang);
			VorlesungDAO.save(vorlesung5);
			Vorlesung vorlesung6 = VorlesungDAO.createVorlesung();
			vorlesung6.setName("Rechnernetze");
			vorlesung6.setEcts(5);
			vorlesung6.setSws(5);
			vorlesung6.setStudiengang(win);
			VorlesungDAO.save(vorlesung6);
			// TODO Initialize the properties of the persistent object here, the following
			// properties must be initialized before saving : studiengang, sws, ects
			VorlesungDAO.save(vorlesung);

			t.commit();
		} catch (Exception e) {
			System.out.println(e);
			t.rollback();
		}

	}

	public static void main(String[] args) {
		try {
			CreateAufgabe1Data createAufgabe1Data = new CreateAufgabe1Data();
			try {
				createAufgabe1Data.createTestData();
			} finally {
				Aufgabe1PersistentManager.instance().disposePersistentManager();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
