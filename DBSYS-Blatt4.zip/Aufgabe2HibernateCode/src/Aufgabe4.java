import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.orm.*;

public class Aufgabe4 {

    public static void main(String[] args) throws PersistentException {
        SessionFactory s = Aufgabe1PersistentManager.instance().getSession().getSessionFactory();
        Session session = s.openSession();
        Transaction tx = session.beginTransaction();
        /*
         * Query query = session.createQuery("from Vorlesung");
         * List<Vorlesung> test = query.list();
         * 
         * for (Vorlesung v : test) {
         * System.out.println("Name: " + v.getName() + " | ECTS: " + v.getEcts() +
         * " | Studiengang: "
         * + v.getStudiengang().toString());
         * }
         */
        Query query2 = session.createQuery("Select concat(name, ' ', ECTS, ' ', studiengang) from Vorlesung");
        List<String> tmp2 = query2.list();
        for (String name : tmp2) {
            System.out.println(name);
        }
        tx.commit();
        session.close();
    }

}
