/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Laboradmin(HTWG Konstanz)
 * License Type: Academic
 */
public interface ORMConstants extends org.orm.util.ORMBaseConstants {
	final int KEY_STUDIENGANG_VORLESUNG = 1334328835;
	
	final int KEY_VORLESUNG_STUDIENGANG = -1778203517;
	
}
