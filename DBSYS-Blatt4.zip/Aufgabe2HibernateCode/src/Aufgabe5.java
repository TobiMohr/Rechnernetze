import java.util.List;

import org.apache.logging.log4j.core.appender.SyslogAppender;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.orm.*;

public class Aufgabe5 {

    public static void main(String[] args) throws PersistentException {
        SessionFactory s = Aufgabe1PersistentManager.instance().getSession().getSessionFactory();
        Session session = s.openSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery(" from Studiengang");
        List<Studiengang> studiengänge = query.list();
        System.out.println(studiengänge.size());
        for (Studiengang studiengang : studiengänge) {
            System.out.println(studiengang.getName());
            query = session.createQuery("SELECT sum(ects)from Vorlesung where Studiengangkuerzel=:kuerzel");
            query.setString("kuerzel", studiengang.getKuerzel());
            long ects = (long) query.uniqueResult();
            System.out.println("Summe: " + ects);
        }
        // DAS IST DIE BESSERE VARIANTE
        Query query2 = session.createQuery(
                "Select concat(s.name ,' ',SUM(v.ects)) from Studiengang s, Vorlesung v where v.studiengang=s.kuerzel group by s.name");
        List<String> t = query2.list();
        for (String name : t) {
            System.out.println(name);
        }
        tx.commit();
        session.close();

    }
}
