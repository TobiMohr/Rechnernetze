/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Laboradmin(HTWG Konstanz)
 * License Type: Academic
 */
public class Vorlesung {
	public Vorlesung() {
	}
	
	private void this_setOwner(Object owner, int key) {
		if (key == ORMConstants.KEY_VORLESUNG_STUDIENGANG) {
			this.studiengang = (Studiengang) owner;
		}
	}
	
	org.orm.util.ORMAdapter _ormAdapter = new org.orm.util.AbstractORMAdapter() {
		public void setOwner(Object owner, int key) {
			this_setOwner(owner, key);
		}
		
	};
	
	private int ID;
	
	private String name;
	
	private int ects;
	
	private int sws;
	
	private Studiengang studiengang;
	
	private void setID(int value) {
		this.ID = value;
	}
	
	public int getID() {
		return ID;
	}
	
	public int getORMID() {
		return getID();
	}
	
	public void setName(String value) {
		this.name = value;
	}
	
	public String getName() {
		return name;
	}
	
	public void setEcts(int value) {
		this.ects = value;
	}
	
	public int getEcts() {
		return ects;
	}
	
	public void setSws(int value) {
		this.sws = value;
	}
	
	public int getSws() {
		return sws;
	}
	
	public void setStudiengang(Studiengang value) {
		if (studiengang != null) {
			studiengang.vorlesung.remove(this);
		}
		if (value != null) {
			value.vorlesung.add(this);
		}
	}
	
	public Studiengang getStudiengang() {
		return studiengang;
	}
	
	/**
	 * This method is for internal use only.
	 */
	public void setORM_Studiengang(Studiengang value) {
		this.studiengang = value;
	}
	
	private Studiengang getORM_Studiengang() {
		return studiengang;
	}
	
	public String toString() {
		return String.valueOf(getID());
	}
	
}
