import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.orm.*;

public class Aufgabe6 {

    public static void main(String[] args) throws PersistentException {
        SessionFactory s = Aufgabe1PersistentManager.instance().getSession().getSessionFactory();
        Session session = s.openSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery(
                "Select DISTINCT v.name From Vorlesung v, Vorlesung v1 where v.name=v1.name And v.studiengang!=v1.studiengang");

        String name = (String) query.uniqueResult();
        System.out.println(name);
        tx.commit();
        session.close();

    }

}
