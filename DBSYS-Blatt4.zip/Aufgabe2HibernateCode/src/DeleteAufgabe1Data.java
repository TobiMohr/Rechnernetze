/**
 * Licensee: Laboradmin(HTWG Konstanz)
 * License Type: Academic
 */
import org.orm.*;
public class DeleteAufgabe1Data {
	public void deleteTestData() throws PersistentException {
		PersistentTransaction t = Aufgabe1PersistentManager.instance().getSession().beginTransaction();
		try {
			Vorlesung vorlesung = VorlesungDAO.loadVorlesungByQuery(null, null);
			// Delete the persistent object
			VorlesungDAO.delete(vorlesung);
			Studiengang studiengang = StudiengangDAO.loadStudiengangByQuery(null, null);
			// Delete the persistent object
			StudiengangDAO.delete(studiengang);
			t.commit();
		}
		catch (Exception e) {
			t.rollback();
		}
		
	}
	
	public static void main(String[] args) {
		try {
			DeleteAufgabe1Data deleteAufgabe1Data = new DeleteAufgabe1Data();
			try {
				deleteAufgabe1Data.deleteTestData();
			}
			finally {
				Aufgabe1PersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
