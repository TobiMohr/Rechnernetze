/**
 * Licensee: Laboradmin(HTWG Konstanz)
 * License Type: Academic
 */
import org.orm.*;
public class RetrieveAndUpdateAufgabe1Data {
	public void retrieveAndUpdateTestData() throws PersistentException {
		PersistentTransaction t = Aufgabe1PersistentManager.instance().getSession().beginTransaction();
		try {
			Studiengang studiengang = StudiengangDAO.loadStudiengangByQuery(null, null);
			// Update the properties of the persistent object

			StudiengangDAO.save(studiengang);
			Vorlesung vorlesung = VorlesungDAO.loadVorlesungByQuery(null, null);


			// Update the properties of the persistent object
			VorlesungDAO.save(vorlesung);

			t.commit();
		}
		catch (Exception e) {
			t.rollback();
		}
		
	}
	
	public void retrieveByCriteria() throws PersistentException {
		System.out.println("Retrieving Vorlesung by VorlesungCriteria");
		VorlesungCriteria vorlesungCriteria = new VorlesungCriteria();
		// Please uncomment the follow line and fill in parameter(s)
		//vorlesungCriteria.ID.eq();
		System.out.println(vorlesungCriteria.uniqueVorlesung());
		
		System.out.println("Retrieving Studiengang by StudiengangCriteria");
		StudiengangCriteria studiengangCriteria = new StudiengangCriteria();
		// Please uncomment the follow line and fill in parameter(s)
		//studiengangCriteria.kuerzel.eq();
		System.out.println(studiengangCriteria.uniqueStudiengang());
		
	}
	
	
	public static void main(String[] args) {
		try {
			RetrieveAndUpdateAufgabe1Data retrieveAndUpdateAufgabe1Data = new RetrieveAndUpdateAufgabe1Data();
			try {
				retrieveAndUpdateAufgabe1Data.retrieveAndUpdateTestData();
				//retrieveAndUpdateAufgabe1Data.retrieveByCriteria();
			}
			finally {
				Aufgabe1PersistentManager.instance().disposePersistentManager();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
