/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Licensee: Laboradmin(HTWG Konstanz)
 * License Type: Academic
 */
@Entity
@Table(name="STUDIENGANG")
public class Studiengang {
	public Studiengang() {
	}
	
	private java.util.Set this_getSet (int key) {
		if (key == ORMConstants.KEY_STUDIENGANG_VORLESUNG) {
			return ORM_vorlesung;
		}
		
		return null;
	}
	
	org.orm.util.ORMAdapter _ormAdapter = new org.orm.util.AbstractORMAdapter() {
		public java.util.Set getSet(int key) {
			return this_getSet(key);
		}
		
	};
	private String kuerzel;
	
	private String name;
	
	private String abschluss;
	
	private java.util.Set ORM_vorlesung = new java.util.HashSet();
	
	public void setKuerzel(String value) {
		this.kuerzel = value;
	}
	
	public String getKuerzel() {
		return kuerzel;
	}
	
	public String getORMID() {
		return getKuerzel();
	}
	
	public void setName(String value) {
		this.name = value;
	}
	
	public String getName() {
		return name;
	}
	
	public void setAbschluss(String value) {
		this.abschluss = value;
	}
	
	public String getAbschluss() {
		return abschluss;
	}
	
	private void setORM_Vorlesung(java.util.Set value) {
		this.ORM_vorlesung = value;
	}
	
	private java.util.Set getORM_Vorlesung() {
		return ORM_vorlesung;
	}
	
	public final VorlesungSetCollection vorlesung = new VorlesungSetCollection(this, _ormAdapter, ORMConstants.KEY_STUDIENGANG_VORLESUNG, ORMConstants.KEY_VORLESUNG_STUDIENGANG, ORMConstants.KEY_MUL_ONE_TO_MANY);
	
	public String toString() {
		return String.valueOf(getKuerzel());
	}
	
}
