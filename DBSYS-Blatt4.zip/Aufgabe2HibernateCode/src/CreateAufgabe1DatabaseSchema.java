/**
 * Licensee: Laboradmin(HTWG Konstanz)
 * License Type: Academic
 */
import org.orm.*;
public class CreateAufgabe1DatabaseSchema {
	public static void main(String[] args) {
		try {
			ORMDatabaseInitiator.createSchema(Aufgabe1PersistentManager.instance());
			Aufgabe1PersistentManager.instance().disposePersistentManager();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
