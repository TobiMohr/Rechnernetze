/**
 * "Visual Paradigm: DO NOT MODIFY THIS FILE!"
 * 
 * This is an automatic generated file. It will be regenerated every time 
 * you generate persistence class.
 * 
 * Modifying its content may cause the program not work, or your work may lost.
 */

/**
 * Licensee: Laboradmin(HTWG Konstanz)
 * License Type: Academic
 */
import org.orm.*;
import org.hibernate.Query;
import org.hibernate.LockMode;
import java.util.List;

public class VorlesungDAO {
	public static Vorlesung loadVorlesungByORMID(int ID) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return loadVorlesungByORMID(session, ID);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung getVorlesungByORMID(int ID) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return getVorlesungByORMID(session, ID);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung loadVorlesungByORMID(int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return loadVorlesungByORMID(session, ID, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung getVorlesungByORMID(int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return getVorlesungByORMID(session, ID, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung loadVorlesungByORMID(PersistentSession session, int ID) throws PersistentException {
		try {
			return (Vorlesung) session.load(Vorlesung.class, Integer.valueOf(ID));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung getVorlesungByORMID(PersistentSession session, int ID) throws PersistentException {
		try {
			return (Vorlesung) session.get(Vorlesung.class, Integer.valueOf(ID));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung loadVorlesungByORMID(PersistentSession session, int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Vorlesung) session.load(Vorlesung.class, Integer.valueOf(ID), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung getVorlesungByORMID(PersistentSession session, int ID, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			return (Vorlesung) session.get(Vorlesung.class, Integer.valueOf(ID), lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryVorlesung(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return queryVorlesung(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryVorlesung(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return queryVorlesung(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung[] listVorlesungByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return listVorlesungByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung[] listVorlesungByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return listVorlesungByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryVorlesung(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Vorlesung as Vorlesung");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.list();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static List queryVorlesung(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Vorlesung as Vorlesung");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("Vorlesung", lockMode);
			return query.list();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung[] listVorlesungByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		try {
			List list = queryVorlesung(session, condition, orderBy);
			return (Vorlesung[]) list.toArray(new Vorlesung[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung[] listVorlesungByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			List list = queryVorlesung(session, condition, orderBy, lockMode);
			return (Vorlesung[]) list.toArray(new Vorlesung[list.size()]);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung loadVorlesungByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return loadVorlesungByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung loadVorlesungByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return loadVorlesungByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung loadVorlesungByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		Vorlesung[] vorlesungs = listVorlesungByQuery(session, condition, orderBy);
		if (vorlesungs != null && vorlesungs.length > 0)
			return vorlesungs[0];
		else
			return null;
	}
	
	public static Vorlesung loadVorlesungByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		Vorlesung[] vorlesungs = listVorlesungByQuery(session, condition, orderBy, lockMode);
		if (vorlesungs != null && vorlesungs.length > 0)
			return vorlesungs[0];
		else
			return null;
	}
	
	public static java.util.Iterator iterateVorlesungByQuery(String condition, String orderBy) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return iterateVorlesungByQuery(session, condition, orderBy);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateVorlesungByQuery(String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		try {
			PersistentSession session = Aufgabe1PersistentManager.instance().getSession();
			return iterateVorlesungByQuery(session, condition, orderBy, lockMode);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateVorlesungByQuery(PersistentSession session, String condition, String orderBy) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Vorlesung as Vorlesung");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static java.util.Iterator iterateVorlesungByQuery(PersistentSession session, String condition, String orderBy, org.hibernate.LockMode lockMode) throws PersistentException {
		StringBuffer sb = new StringBuffer("From Vorlesung as Vorlesung");
		if (condition != null)
			sb.append(" Where ").append(condition);
		if (orderBy != null)
			sb.append(" Order By ").append(orderBy);
		try {
			Query query = session.createQuery(sb.toString());
			query.setLockMode("Vorlesung", lockMode);
			return query.iterate();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung createVorlesung() {
		return new Vorlesung();
	}
	
	public static boolean save(Vorlesung vorlesung) throws PersistentException {
		try {
			Aufgabe1PersistentManager.instance().saveObject(vorlesung);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean delete(Vorlesung vorlesung) throws PersistentException {
		try {
			Aufgabe1PersistentManager.instance().deleteObject(vorlesung);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean deleteAndDissociate(Vorlesung vorlesung)throws PersistentException {
		try {
			if (vorlesung.getStudiengang() != null) {
				vorlesung.getStudiengang().vorlesung.remove(vorlesung);
			}
			
			return delete(vorlesung);
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean deleteAndDissociate(Vorlesung vorlesung, org.orm.PersistentSession session)throws PersistentException {
		try {
			if (vorlesung.getStudiengang() != null) {
				vorlesung.getStudiengang().vorlesung.remove(vorlesung);
			}
			
			try {
				session.delete(vorlesung);
				return true;
			} catch (Exception e) {
				return false;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean refresh(Vorlesung vorlesung) throws PersistentException {
		try {
			Aufgabe1PersistentManager.instance().getSession().refresh(vorlesung);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static boolean evict(Vorlesung vorlesung) throws PersistentException {
		try {
			Aufgabe1PersistentManager.instance().getSession().evict(vorlesung);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new PersistentException(e);
		}
	}
	
	public static Vorlesung loadVorlesungByCriteria(VorlesungCriteria vorlesungCriteria) {
		Vorlesung[] vorlesungs = listVorlesungByCriteria(vorlesungCriteria);
		if(vorlesungs == null || vorlesungs.length == 0) {
			return null;
		}
		return vorlesungs[0];
	}
	
	public static Vorlesung[] listVorlesungByCriteria(VorlesungCriteria vorlesungCriteria) {
		return vorlesungCriteria.listVorlesung();
	}
}
